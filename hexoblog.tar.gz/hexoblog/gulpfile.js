require('./themes/hexo-theme-snippet/gulpfile');
